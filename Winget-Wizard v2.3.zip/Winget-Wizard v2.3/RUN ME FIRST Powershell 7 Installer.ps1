# Check if Windows Package Manager (winget) is installed
if (!(Get-Command winget -ErrorAction SilentlyContinue)) {
  Write-Host "Installing Windows Package Manager (winget)..." -ForegroundColor Yellow
  $install_cmd = "Invoke-Expression ((New-Object System.Net.WebClient).DownloadString('https://raw.githubusercontent.com/microsoft/winget-cli/master/scripts/install.ps1'))"
  Start-Process powershell.exe -ArgumentList "-Command $install_cmd" -Verb RunAs -Wait
}

# Install PowerShell 7 using Windows Package Manager
Write-Host "Installing PowerShell 7..." -ForegroundColor Yellow
winget install --id=Microsoft.PowerShell -e
